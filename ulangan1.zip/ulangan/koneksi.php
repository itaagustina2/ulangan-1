<?php

$servername="localhost";
$database="php_rud";
$username="root";
$password="";
// Create connection
$conn=mysqli_connect($servername,
$username,$password,$database);
// Check connection
if (!$conn){
	die("Gagal:".mysqli_connect_error());
}
echo "Anda Berhasil Terhubung";
mysqli_close($conn);
?>